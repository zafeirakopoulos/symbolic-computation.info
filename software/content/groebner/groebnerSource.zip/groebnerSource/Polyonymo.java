
import java.lang.*;
import java.util.*;
import java.math.*;
import java.io.*;

public class Polyonymo
 {
  TreeMap mononyma;
  Comparator order;
  Field field;

  public Polyonymo(TreeMap m)
   {
    order=m.comparator();
    if (!(m.size()==0))
     {
      field= ((Term)m.get(m.firstKey())).synt.getField();
     }
    else
     {
      field=new ModField("5");
     }

    mononyma=m;
   }

  public Polyonymo(Term[] ta, Comparator c)
   {
    order=c;
    mononyma=new TreeMap(order);
    for (int i=0;i<ta.length;i++)
     {
      mononyma.put(ta[i].mon,ta[i]);
     }
    field= ((Term)mononyma.get(mononyma.firstKey())).synt.getField();
   }


  public Polyonymo copy()
   {
    return new Polyonymo(new TreeMap(mononyma));
   }

  public Polyonymo add(Term t)
   {
    TreeMap ret=new TreeMap(mononyma);
    FieldElement fe;
    Mononymo m;
    for(Iterator i=mononyma.keySet().iterator();i.hasNext();)
     {
      m=(Mononymo)i.next();
      ret.put(m.copy(), new Term(m.copy(), ((Term)mononyma.get(m)).synt.copy() ));
     }   
    if (ret.containsKey(t.mon))
     {
      fe=((Term)ret.get(t.mon)).synt.copy();
      fe.add(t.synt);
      if (!fe.isZero())
       {
        ((Term)ret.get(t.mon)).synt=fe;
       }
     }
    else
     {
      ret.put(t.mon,t);
     }
    return new Polyonymo(ret);
   }
  
  public Polyonymo substract(Term t)
   {
    TreeMap ret=new TreeMap(mononyma);
    FieldElement fe;
    Mononymo m;
    for(Iterator i=mononyma.keySet().iterator();i.hasNext();)
     {
      m=(Mononymo)i.next();
      ret.put(m.copy(), new Term(m.copy(), ((Term)mononyma.get(m)).synt.copy() ));
     }   
    if (ret.containsKey(t.mon))
     {
      fe=((Term)ret.get(t.mon)).synt;
      fe.substract(t.synt);
      if (!fe.isZero())
       {
        ((Term)ret.get(t.mon)).synt=fe;
       }
     }
    else
     {
      fe=t.synt.copy();
      fe.negate();
      ret.put(t.mon,t);
     }
    return new Polyonymo(ret);
   }
    
  public Polyonymo multiply(Term t)
   {
    Mononymo m;
    Term tt;
    TreeMap ret=new TreeMap(order);
    FieldElement fe;
    for(Iterator i=mononyma.keySet().iterator();i.hasNext();)
     {
      m=(Mononymo)i.next();
      fe=((Term)mononyma.get(m)).synt.copy();
      fe.multiply(t.synt);
      if (!fe.isZero())
       {
        tt=new Term( ((Term)mononyma.get(m)).mon.multiply(t.mon), fe);
        ret.put(tt.mon,tt) ;
       }
     }
    return new Polyonymo(ret);
   }

  public Polyonymo  substract(Polyonymo p)
   {
    Mononymo m;
    Term tt;
    TreeMap tmp=new TreeMap(order);
    FieldElement fe;

    for(Iterator i=mononyma.keySet().iterator();i.hasNext();)
     {
      m=(Mononymo)i.next();
      tmp.put(m.copy(), new Term(m.copy(), ((Term)mononyma.get(m)).synt.copy() ));
     }   


    for(Iterator i=p.mononyma.keySet().iterator();i.hasNext();)
     {
      m=(Mononymo)i.next();
      if (tmp.containsKey(m))
       {
        fe=((Term)tmp.get(m)).synt.copy();
        fe.substract(((Term)p.mononyma.get(m)).synt);
        if (!fe.isZero())
         {
          ((Term)tmp.get(m)).synt=fe;
         }
        else
         {
          tmp.remove(m);
         } 
       }
      else
       {
        Term n=(Term)p.mononyma.get(m);
        fe=n.synt.copy();
        fe.negate();
        tmp.put( n.mon, new Term(n.mon ,fe)) ;
       }
     }
    return new Polyonymo(tmp);
   }  
  
  public Polyonymo spol(Polyonymo p)
   {
    Polyonymo tmp;
    Polyonymo tmp2;

    Mononymo lcm= ((Term)mononyma.get(mononyma.firstKey())).mon.lcm( ((Term)p.mononyma.get(p.mononyma.firstKey())).mon);
    FieldElement fe=((Term)mononyma.get(mononyma.firstKey())).synt.copy();
    fe.inverse(); 
    Term t=new Term( lcm.divide(((Term)mononyma.get(mononyma.firstKey())).mon ),fe);
    tmp=this.multiply(t);

    
    fe=((Term)p.mononyma.get(p.mononyma.firstKey())).synt.copy();
    fe.inverse(); 
    t=new Term( lcm.divide(((Term)p.mononyma.get(p.mononyma.firstKey())).mon ),fe);

    return  tmp.substract(p.multiply(t));

   }

  public Polyonymo modulo(Vector d)
   {
    Polyonymo rest=new Polyonymo(new TreeMap(order));   
    Polyonymo r=new Polyonymo(new TreeMap(mononyma));   
    Polyonymo t;
    Term q;
    boolean cont=true;    
    FieldElement fe;
    while(true)
     {
      cont=false;
      if (r.isZero())
       {
        return rest;
       }
      for (int i=0;i<d.size();i++)
       {
        if ( r.getLT().mon.divisible(((Polyonymo)d.elementAt(i)).getLT().mon))
         {
          cont=true;
          fe=r.getLT().synt.copy();
          fe.divide(((Polyonymo)d.elementAt(i)).getLT().synt);
          q=new Term( r.getLT().mon.divide( ((Polyonymo)d.elementAt(i)).getLT().mon ), fe );
          t=((Polyonymo)d.elementAt(i)).multiply(q);
          r=r.substract(t);
          break;
         }
       }
      if (!cont)
       {
        rest=rest.add((Term)r.mononyma.remove(r.getLT().mon));
       }
     }
   }


  public Object[] division(Vector d)
   {
    Polyonymo rest=new Polyonymo(new TreeMap(order));   
    Polyonymo r=new Polyonymo(new TreeMap(mononyma));   
    Polyonymo[] Q=new Polyonymo[d.size()];
    Arrays.fill(Q,new Polyonymo(new TreeMap(order)));
    Polyonymo t;
    Term q;
    boolean cont=true;    
    FieldElement fe;
    while(true)
     {
      cont=false;
      if (r.isZero())
       {
        return new Object[]{Q,rest};
       }
      for (int i=0;i<d.size();i++)
       {
        if ( r.getLT().mon.divisible(((Polyonymo)d.elementAt(i)).getLT().mon))
         {
          cont=true;
          fe=r.getLT().synt.copy();
          fe.divide(((Polyonymo)d.elementAt(i)).getLT().synt);
          q=new Term( r.getLT().mon.divide( ((Polyonymo)d.elementAt(i)).getLT().mon ), fe );
          t=((Polyonymo)d.elementAt(i)).multiply(q);
          r=r.substract(t);
          Q[i]=Q[i].add(q);
          break;
         }
       }
      if (!cont)
       {
        rest.add((Term)r.mononyma.remove(r.getLT().mon));
       }
     }
   }


  public Term getLT()
   {
    return (Term)mononyma.get(mononyma.firstKey());
   }

  public boolean isZero()
   {
    return (mononyma.size()==0);
   }
  public int compareTo(Object o)
   {
    Mononymo m1=((Term)mononyma.get(mononyma.firstKey())).mon;
    Mononymo m2=((Term)((Polyonymo)o).mononyma.get(((Polyonymo)o).mononyma.firstKey())).mon;
    return order.compare(m1,m2);
   }

  public String toString()
   {  
    boolean first=true;
    String s=" ";
    for(Iterator i=mononyma.keySet().iterator();i.hasNext();)
     {
      if (!first)
       {
        s+=" + ";
       }
      first=false;
      Mononymo tm=(Mononymo)i.next();
      s+=((Term)mononyma.get(tm)).toString();
     }
    return s+" ";
   }


 }
 