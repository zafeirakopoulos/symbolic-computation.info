

public class Term
 {
  Mononymo mon;
  FieldElement synt;
  
  public Term(Mononymo m,FieldElement fe)
   {
    mon=m;
    synt=fe;
   }
  
  public String toString()
   {
    return synt.toString()+mon.toString();
   }
  
 }
