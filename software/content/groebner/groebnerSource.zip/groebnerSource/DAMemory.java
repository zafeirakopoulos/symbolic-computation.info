import java.lang.reflect.*;
import java.awt.* ;
import javax.swing.*;
import java.awt.event.* ;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.io.*;


public class DAMemory
 {
  Hashtable memory;
  JList list=new JList();
  String s;
  Vector vector=new Vector();
  Vector labvector=new Vector();
  public DAMemory()
   {
    memory=new Hashtable();
   }

  public JList getMemoryList()
   {
    list.setListData(labvector);
    return list;  
   }

  public String getMemoryString()
   {
    s="Memory: <br>";
    for (int i=0;i<vector.size();i++)
     {
      s+=(String)vector.elementAt(i);
      s+="<br>";
     }
    return s;
   }

  public void add(String key,Object val)
   {
    if (null!=memory.get(key))
     {

     labvector.removeElement(new String("<html>"+key+"--->"+(memory.get(key)).toString()+"</html>"));  // experimental
      vector.removeElement(new String(key+"--->"+(memory.get(key)).toString()));
     }
    memory.put(key,val);
    labvector.addElement(new String("<html>"+key+"--->"+val.toString()+"</html>"));
    vector.addElement(new String(key+"--->"+val.toString()));
   }  
  public void remove(String key)
   {
    labvector.removeElement(new String("<html>"+key+"--->"+(memory.get(key)).toString()+"</html>"));  // experimental
    vector.removeElement(new String(key+"--->"+(memory.get(key)).toString()));
    memory.remove(key);
   }  

  public Object get(String key)
   {
    return memory.get(key);
   }  

  public String getString(String key)
   {
    return new String(key+"--->"+(memory.get(key)).toString());
   }  

  public void clear()
   {
    memory.clear();
   }
  public boolean containsKey(String key)
   {
    return memory.containsKey(key);
   }
  public java.util.Set getKeys()
   {
    return memory.keySet();
   }
 }
