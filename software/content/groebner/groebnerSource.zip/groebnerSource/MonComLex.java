import java.lang.reflect.*;
import java.awt.* ;
import javax.swing.*;
import java.awt.event.* ;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.io.*;



class MonComLex implements Comparator
 {
  public int compare(Object mm1,Object mm2)
   {
    Mononymo m1=(Mononymo)mm1;
    Mononymo m2=(Mononymo)mm2;
    for (int i=0;i<m1.ekthetes.length;i++)
     {
      if (m1.ekthetes[i]>m2.ekthetes[i])
        {
         return -1;
        }
      else if (m1.ekthetes[i]<m2.ekthetes[i])
        {
         return 1;
        }
     }
    return 0;
   }

 }
