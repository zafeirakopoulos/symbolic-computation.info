
import java.lang.reflect.*;
import java.awt.* ;
import javax.swing.*;
import java.awt.event.* ;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.io.*;

public class ComLine extends JFrame implements KeyListener,ActionListener
 {
  File tmpFile;
  JSplitPane jsl1,jsl2,jsl3;
  Hashtable[]   messages=new Hashtable[]{new Hashtable(),new Hashtable(),new Hashtable()};
  CommandSet comset;
  JEditorPane ta;
  static JEditorPane dta;
  JTextField tf;
  Class cs;
  Method[] commands;
  JScrollPane jsp,jsp2,jsp3;
  String disp="";
  JList memo=new JList();
  JMenuBar mb=new JMenuBar();
  JMenu file =new JMenu();
  JMenuItem newd=new JMenuItem();
  JMenu about=new JMenu();
  JMenuItem aboutme=new JMenuItem();
  JMenuItem help=new JMenuItem();

  JMenuItem closew=new JMenuItem();

  static String dis="";

  int lang=0;

  public ComLine() 
   { 
    new HelpWin();
    createMessages();
    file.add(closew);
    about.add(aboutme);
    about.add(help);

    mb.add(file);
    mb.add(about);  

    newd.addActionListener(this);
    aboutme.addActionListener(this);
    help.addActionListener(this);
    closew.addActionListener(this);
    this.setJMenuBar(mb);
    
    jsl1=new JSplitPane(JSplitPane.VERTICAL_SPLIT,true);
    jsl2=new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,true);
    jsl3=new JSplitPane(JSplitPane.VERTICAL_SPLIT,true);

    jsl1.setResizeWeight(0.8d);
    jsl2.setResizeWeight(0.7d);
    jsl3.setResizeWeight(0.9d);
    memo= DigitAlgebra.getMemory().getMemoryList();
    comset=new CommandSet();
    cs = comset.getClass();
    ta=new JEditorPane();
    ta.setEditable(false);
    ta.setContentType("text/html");

    dta=new JEditorPane();
    dta.setEditable(false);
    dta.setContentType("text/html");

    tf=new JTextField();
    tf.addKeyListener(this);

    jsp=new JScrollPane(ta);
    jsp2=new JScrollPane(memo);
    jsp3=new JScrollPane(dta);


    jsl1.add(jsp);
    jsl1.add(jsp3);

    jsl2.add(jsl1);
    jsl2.add(jsp2);

    jsl3.add(jsl2);
    jsl3.add(tf);

    this.getContentPane().add(jsl3);
    this.setSize(500,500);
    this.setDefaultCloseOperation (EXIT_ON_CLOSE);

    disp+="<br><font color=green>"+ messages[0].get("initial_message") +"</font><br>";
    ta.setText("<html>" + disp + "</html>");
    this.show();
   }

  public static void main(String[] args)
   {
    new ComLine();
   }


 public void createMessages()  
   {
    String keytmp;
    byte[] databytes=null;

    messages[0].put("file","������");
    messages[0].put("help","�������");
    messages[0].put("about","About");
    messages[0].put("aboutText","��������������� ����������");
    messages[0].put("new","���");
    messages[0].put("exit","������");
    messages[0].put("tooManyArgs","����� ��������");
    messages[0].put("initial_message","��� �� ����� ����������� ��� ��� ������ ��������������� help onoma_entolis <br>");
    changeLang(0);

   }


  public void changeLang(int i)
   {
    lang=i;
 
    file.setText((String)messages[lang].get("file"));
    about.setText((String)messages[lang].get("about"));

    help.setText((String)messages[lang].get("help"));

    aboutme.setText((String)messages[lang].get("about"));
    closew.setText((String)messages[lang].get("exit"));
   }

  public void actionPerformed(ActionEvent a)
   {
    String input="";
    String comand=a.getActionCommand();

   if (comand.equals("��������"))
      {
       changeLang(0);
      }
   else if (comand.equals("English"))
      {
       changeLang(1);
      }
   else if (comand.equals("Espanol"))
      {
       changeLang(2);
      }
    else if (comand.equals(messages[lang].get("exit")))
      {
       System.exit(0); 
      }
    else if (comand.equals(messages[lang].get("help")))
      {
       new HelpWin();
      }
    else if (comand.equals(messages[lang].get("about")))
      {
       new AboutWin();
      }

  }

 public void exec()
  {
   new Chooser();
  }

 public void execute()
  {
   try
    {
     LineNumberReader br=new LineNumberReader(new FileReader(tmpFile));
     String comm=br.readLine();
 
     while (!comm.equals("end"))
      {
       tf.setText(comm);
       proccesString();
       comm=br.readLine();
      } 
    }
   catch (Exception ee)
    {
     System.out.println(ee);
    }
  }


 public void proccesString()
  {
      try
       {
        StringTokenizer st=new StringTokenizer(tf.getText(), " ");
        if (st.countTokens()>2)
         {
          disp+="<br>"+ (String)messages[lang].get("tooManyArgs")+"<br>";
          ta.setText("<html>" + disp + "</html>");
          tf.setText("");
         }
        else if (st.countTokens()<2)
         {
          Method meth= cs.getMethod(st.nextToken(),new Class[]{String.class});
          disp+=((String)meth.invoke(comset,new String[]{""}))+"<br><br>";
          ta.setText("<html>" + disp + "</html>");
          tf.setText("");
         }
        else
         {
          Method meth= cs.getMethod(st.nextToken(),new Class[]{String.class});
          disp+=((String)meth.invoke(comset,new String[]{st.nextToken()}))+"<br><br>";
          ta.setText("<html>" + disp + "</html>");
          tf.setText("");
         }
        memo= DigitAlgebra.getMemory().getMemoryList();
       }
      catch (Exception eee)
       {
        disp+="<br><font color=red>"+ eee +"<br></font><br>";
        ta.setText("<html>" + disp + "</html>");
        tf.setText("");
       }
  }

// ===== Start of KeyListener Implementation =====


 public void keyTyped(KeyEvent ke)
   {
    if (ke.getKeyChar()==KeyEvent.VK_ENTER)
     {
      proccesString();
     }
   }
 public void keyPressed(KeyEvent ke)
   {
   }
 public void keyReleased(KeyEvent ke)
   {
   }
// ==== End of KeyListener Implementation =====

 public static void details(String s)
  {
   dis+="<br><font color=green>"+ s +"</font><br>";
   dta.setText("<html>" + dis + "</html>");

  }
 public static void alert(String s)
  {
   dis+="<br><font color=red>"+ s +"</font><br>";
   dta.setText("<html>" + dis + "</html>");
  }

class AboutWin extends JFrame
 {
  public AboutWin()
   {
    this.setTitle((String)messages[lang].get("about"));
    JLabel l1=new JLabel((String)messages[lang].get("aboutText"),JLabel.CENTER);
    this.getContentPane().add(l1);
    this.setSize(500,200);
    this.setResizable(false);
    this.show();
   }
 }


class HelpWin extends JFrame
 {
  public HelpWin()
   {
    
    String s="<html> �� ��������� ���� ��� ���� �����������: <br> �������� ���������� <br> ������ ����� Groebner <br> �������������� ����� Groebner. <br> �������� <<script>> <br><br> ����� �������: <br> pol <br> poldiv <br> gb  <br> spol <br> gbmin <br>mem <br> exec <br> ��� �� ����� ��� ������� ��������� ���� ������� ������ help �����_������� <br><br><br> ��������� �� ��������� ���t������ ���� ������ Zp. <br><br> <A HREF=mailto:mathuoa@yahoo.gr >mathuoa@yahoo.gr </A><br><br> <A HREF=www.geocities.com/mathuoa/439/da/ >� ������ ��� ������������ </A>";
    this.setTitle((String)messages[lang].get("help"));
    JEditorPane ta=new JEditorPane();
    ta.setEditable(false);
    ta.setContentType("text/html");
    ta.setText(s);
    JScrollPane jsp=new JScrollPane(ta);
    this.getContentPane().add(jsp);

    this.setSize(500,500);
    this.setResizable(false);
    this.show();
   }
 }

 class Chooser extends JFrame implements ActionListener
   {
    JFileChooser jfc;
    public Chooser()
     {
      this.setTitle("������� �������");
      jfc=new JFileChooser();
      jfc.addActionListener(this);
      this.getContentPane().add(jfc);
      this.setSize(400,300);
      this.setLocation(100,100);
      this.show();
     }
    public void actionPerformed(ActionEvent e)
     {
      tmpFile=jfc.getSelectedFile();     
      execute();
      this.dispose();
     }
   }

 }

 
