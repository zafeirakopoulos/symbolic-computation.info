public class DigitAlgebra
 {
  static DAMemory memory;
  static ComLine comlin;

  public static void main(String[] args)
   {
    new DigitAlgebra();
   }

  public DigitAlgebra()
   {
    memory=new DAMemory();
    comlin=new ComLine();
   }
  
   public static  DAMemory getMemory()
    {
     return memory;
    }

   public static  ComLine getComLine()
    {
     return comlin;
    }

 }