import java.math.*;

public class Mononymo
 {
  int[] ekthetes=new int[0];
  
  public Mononymo()  
   {
   }
  
  public Mononymo(int[] e)  
   {
    ekthetes=e;
   }

  public Mononymo copy()  
   {
    return new Mononymo((int[])ekthetes.clone());
   }
  
  public void multiplyThis(Mononymo m)
   {
    for (int i=0;i<m.ekthetes.length;i++)
     { 
      ekthetes[i]+=m.ekthetes[i];
     }
   }

  public Mononymo multiply(Mononymo m)
   {
    int[] tmp=new int[ekthetes.length];
    for (int i=0;i<m.ekthetes.length;i++)
     { 
      tmp[i]=ekthetes[i]+m.ekthetes[i];
     } 
    return new Mononymo(tmp);
   }


  public void divideThis(Mononymo m)
   {
    int k;
    for (int i=0;i<m.ekthetes.length;i++)
     { 
      k=ekthetes[i]-m.ekthetes[i];
      if (k>-1)
       {
        ekthetes[i]=k;
       }
      else
       {
//Na pei oti exei problem
       }
     }
   }

  public Mononymo divide(Mononymo m)
   {
    int[] tmp=new int[ekthetes.length];
    int k;
    for (int i=0;i<m.ekthetes.length;i++)
     { 
      k=ekthetes[i]-m.ekthetes[i];
      if (k>-1)
       {
        tmp[i]=k;
       }
      else
       {
        return new Mononymo();
       }
     }
    return new Mononymo(tmp);
   }

  public Mononymo lcm(Mononymo m)
   {
    int[] tmp=new int[ekthetes.length];
    for (int i=0;i<m.ekthetes.length;i++)
     { 
      tmp[i]=Math.max(ekthetes[i],m.ekthetes[i]);
     } 
    return new Mononymo(tmp);
   }

  public boolean  divisible(Mononymo m)
   {
    int k;
    for (int i=0;i<m.ekthetes.length;i++)
     { 
      k=ekthetes[i]-m.ekthetes[i];
      if (k<0)
       {
        return false;
       }
     }
    return true;
   }


  public String toString()
   {
    try
     {
      String s=" "; 
      for (int i=0;i<ekthetes.length;i++)
       {
        s+="X<sub>"+(i+1)+"</sub><sup>"+ ekthetes[i] +"</sup>";
       }
      return s;
     }
    catch(Exception e)
     {
      return " ";
     }
   }


 }