import java.lang.reflect.*;
import java.awt.* ;
import javax.swing.*;
import java.awt.event.* ;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.io.*;

public class PolyFactory
 {

  public static Vector getSpolSet(Polyonymo[] p)
   {
    int k=p.length; 
    Vector tmp=new Vector();
    Polyonymo po;
    for (int i=0;i<k-1;i++)
     for (int j=i+1;j<k;j++)
      {
       po=p[i].spol(p[j]); 
       if (!po.isZero()) 
        {
         tmp.addElement(po);
        }
      }
    return tmp;
   }

 
  public static Vector findGroebner(Polyonymo[] gr)
   {
    Vector tmp=new Vector();
    Vector g=new Vector();
    Polyonymo s,rest;
    for (int j=0;j<gr.length;j++)
     {
      g.addElement(gr[j]);
     }
    for (int i=0;i<gr.length-1;i++)
     for (int j=i+1;j<gr.length;j++)
      {
       s=gr[i].spol(gr[j]); 
       if (!s.isZero()) 
        { 
         tmp.addElement(s);
        }
      }
    while (tmp.size()>0)
     {
      s=(Polyonymo)tmp.lastElement();
      tmp.removeElementAt(tmp.size()-1);
      rest=s.modulo(g);
      if (!rest.isZero())
        {
         g.addElement(rest);
         for (int i=0;i<g.size();i++)
          {
           s=rest.spol((Polyonymo)g.elementAt(i));
           if (!s.modulo(g).isZero()) 
            {
             tmp.add(s);
            }
           else
            {
             System.out.println("ypoloipo 0.");
            }
          }
        }
     }
    return g;
   }


  public static Vector gbmin(Polyonymo[] p)
   {
    boolean toAdd=true;
    Vector tmp=new Vector();
    Term[] lms=new Term[p.length];
    for (int j=0;j<lms.length;j++)
     {
      lms[j]=p[j].getLT();
     }
    for (int k=0;k<lms.length;k++)
     {
      toAdd=true;
      for (int i=0;i<lms.length;i++)
       {
        if (i!=k)
         {
          if (lms[k].mon.divisible(lms[i].mon)) 
           {
            toAdd=false;
            break;    
           }
         }
       }
      if (toAdd)
       {
        tmp.addElement(p[k]);
       }
     }
    return tmp;
   } 
   



 }